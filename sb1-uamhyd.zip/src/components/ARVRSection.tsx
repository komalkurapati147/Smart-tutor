import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Glasses, Brain, Lightbulb } from 'lucide-react';

const ARVRSection = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  });

  return (
    <section id="ar-vr" className="py-20 bg-gradient-to-r from-indigo-50 to-purple-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center"
        >
          <div>
            <h2 className="text-4xl font-bold text-gray-900 mb-6">
              Experience Learning in a New Dimension
            </h2>
            <p className="text-xl text-gray-600 mb-8">
              Step into the future of education with our immersive AR/VR learning experiences. 
              Visualize complex concepts, interact with 3D models, and learn by doing.
            </p>

            <div className="space-y-6">
              <Feature 
                icon={<Glasses />}
                title="Virtual Labs"
                description="Conduct experiments safely in our virtual laboratories"
              />
              <Feature 
                icon={<Brain />}
                title="3D Concept Visualization"
                description="Understand complex topics through interactive 3D models"
              />
              <Feature 
                icon={<Lightbulb />}
                title="Immersive Learning"
                description="Practice real-world scenarios in a risk-free environment"
              />
            </div>

            <motion.button
              whileHover={{ scale: 1.05 }}
              className="mt-8 bg-indigo-600 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-indigo-700 transition-colors"
            >
              Book AR/VR Session
            </motion.button>
          </div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <div className="aspect-w-16 aspect-h-9 rounded-xl overflow-hidden shadow-2xl">
              <img 
                src="https://images.unsplash.com/photo-1626387346567-68d0c49c78e1?auto=format&fit=crop&q=80"
                alt="AR/VR Learning Experience"
                className="object-cover w-full h-full rounded-xl"
              />
            </div>
            
            <div className="absolute -bottom-6 -left-6 bg-white p-4 rounded-lg shadow-lg">
              <div className="text-2xl font-bold text-indigo-600">1000+</div>
              <div className="text-gray-600">AR/VR Modules</div>
            </div>
            
            <div className="absolute -top-6 -right-6 bg-white p-4 rounded-lg shadow-lg">
              <div className="text-2xl font-bold text-indigo-600">98%</div>
              <div className="text-gray-600">Learning Retention</div>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

const Feature = ({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) => (
  <div className="flex items-start space-x-4">
    <div className="flex-shrink-0 p-3 bg-indigo-100 rounded-lg text-indigo-600">
      {icon}
    </div>
    <div>
      <h3 className="text-lg font-semibold text-gray-900">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  </div>
);

export default ARVRSection;