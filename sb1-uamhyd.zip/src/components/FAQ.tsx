import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, ChevronUp } from 'lucide-react';

const FAQ = () => {
  const faqs = [
    {
      question: "How does Smart Tutor's AR/VR learning work?",
      answer: "Our AR/VR technology allows you to immerse yourself in interactive 3D learning environments. Using either a VR headset or AR-enabled device, you can visualize complex concepts, conduct virtual experiments, and practice real-world scenarios in a safe, controlled environment."
    },
    {
      question: "What makes Smart Tutor different from other platforms?",
      answer: "Smart Tutor combines cutting-edge technology with personalized learning paths, live expert mentoring, and research-backed methodologies. Unlike traditional platforms, we offer immersive AR/VR experiences, integrated coding environments, and access to academic research papers."
    },
    {
      question: "How do I access the online compiler?",
      answer: "Our integrated coding environment is available directly through your dashboard. It supports multiple programming languages and provides real-time compilation, debugging tools, and instant feedback on your code."
    },
    {
      question: "Can I access research papers through Smart Tutor?",
      answer: "Yes! Smart Tutor provides access to a vast library of peer-reviewed research papers across various disciplines. You can search, read, and download papers relevant to your studies."
    },
    {
      question: "What kind of support is available?",
      answer: "We offer 24/7 expert support through multiple channels including live chat, video calls, and email. Our mentors are subject matter experts who can help you with doubts, assignments, and career guidance."
    },
    {
      question: "How do I book an AR/VR learning session?",
      answer: "You can book AR/VR sessions directly through your dashboard. Simply select your preferred time slot, topic, and device type (AR or VR). We'll guide you through the setup process before your session begins."
    }
  ];

  return (
    <section id="faq" className="py-20 bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Frequently Asked Questions
          </h2>
          <p className="text-xl text-gray-600">
            Find answers to common questions about Smart Tutor
          </p>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <FAQItem key={index} question={faq.question} answer={faq.answer} />
          ))}
        </div>
      </div>
    </section>
  );
};

const FAQItem = ({ question, answer }: { question: string; answer: string }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <motion.div
      initial={false}
      className="border border-gray-200 rounded-lg overflow-hidden"
    >
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between p-6 text-left bg-white hover:bg-gray-50 transition-colors"
      >
        <span className="text-lg font-semibold text-gray-900">{question}</span>
        {isOpen ? (
          <ChevronUp className="h-5 w-5 text-gray-500" />
        ) : (
          <ChevronDown className="h-5 w-5 text-gray-500" />
        )}
      </button>

      <AnimatePresence initial={false}>
        {isOpen && (
          <motion.div
            initial={{ height: 0 }}
            animate={{ height: "auto" }}
            exit={{ height: 0 }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden"
          >
            <div className="p-6 pt-0 text-gray-600">
              {answer}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

export default FAQ;