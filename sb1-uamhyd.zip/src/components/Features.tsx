import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { 
  BookOpen, 
  Code, 
  Video, 
  FileText, 
  Users, 
  Brain,
  Glasses,
  MessageSquare
} from 'lucide-react';

const Features = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  });

  const features = [
    {
      icon: <Glasses className="h-8 w-8" />,
      title: "Immersive AR/VR Learning",
      description: "Experience concepts in 3D with our cutting-edge AR/VR technology"
    },
    {
      icon: <Code className="h-8 w-8" />,
      title: "Interactive Coding Environment",
      description: "Practice coding with our built-in compiler and real-time feedback"
    },
    {
      icon: <Video className="h-8 w-8" />,
      title: "Live Online Classes",
      description: "Join interactive sessions with expert educators in real-time"
    },
    {
      icon: <FileText className="h-8 w-8" />,
      title: "Research Paper Access",
      description: "Stay updated with latest research and academic publications"
    },
    {
      icon: <Users className="h-8 w-8" />,
      title: "Peer Learning Groups",
      description: "Collaborate with fellow learners in study groups"
    },
    {
      icon: <Brain className="h-8 w-8" />,
      title: "AI-Powered Learning Path",
      description: "Personalized curriculum based on your learning style"
    },
    {
      icon: <BookOpen className="h-8 w-8" />,
      title: "Comprehensive Library",
      description: "Access vast collection of learning resources and materials"
    },
    {
      icon: <MessageSquare className="h-8 w-8" />,
      title: "24/7 Expert Support",
      description: "Get help anytime with our round-the-clock mentoring"
    }
  ];

  return (
    <section id="features" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Why Choose Smart Tutor?
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Experience a revolutionary learning platform that combines technology, 
            expertise, and personalization to deliver exceptional educational outcomes.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow"
            >
              <div className="text-indigo-600 mb-4">{feature.icon}</div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                {feature.title}
              </h3>
              <p className="text-gray-600">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;