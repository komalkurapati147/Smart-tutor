import React from 'react';
import { Brain, Facebook, Twitter, Instagram, Linkedin } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <Brain className="h-8 w-8 text-indigo-400" />
              <span className="text-2xl font-bold">Smart Tutor</span>
            </div>
            <p className="text-gray-400 mb-4">
              Transforming education through technology and innovation. 
              Join us in shaping the future of learning.
            </p>
            <div className="flex space-x-4">
              <SocialLink icon={<Facebook />} href="#" />
              <SocialLink icon={<Twitter />} href="#" />
              <SocialLink icon={<Instagram />} href="#" />
              <SocialLink icon={<Linkedin />} href="#" />
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <FooterLink href="#features">Features</FooterLink>
              <FooterLink href="#ar-vr">AR/VR Lab</FooterLink>
              <FooterLink href="#courses">Courses</FooterLink>
              <FooterLink href="#research">Research</FooterLink>
              <FooterLink href="#faq">FAQ</FooterLink>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Contact</h3>
            <ul className="space-y-2 text-gray-400">
              <li>support@smarttutor.edu</li>
              <li>1-800-SMART-TUTOR</li>
              <li>
                123 Learning Street
                <br />
                Education City, ED 12345
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-gray-800 text-center text-gray-400">
          <p>&copy; {new Date().getFullYear()} Smart Tutor. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

const SocialLink = ({ icon, href }: { icon: React.ReactNode; href: string }) => (
  <a
    href={href}
    className="p-2 text-gray-400 hover:text-white transition-colors"
    target="_blank"
    rel="noopener noreferrer"
  >
    {icon}
  </a>
);

const FooterLink = ({ href, children }: { href: string; children: React.ReactNode }) => (
  <li>
    <a
      href={href}
      className="text-gray-400 hover:text-white transition-colors"
    >
      {children}
    </a>
  </li>
);

export default Footer;