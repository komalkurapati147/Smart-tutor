import React from 'react';
import { motion } from 'framer-motion';
import { Rocket, Brain, BookOpen, Users } from 'lucide-react';

const Hero = () => {
  return (
    <div className="relative overflow-hidden pt-32 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center"
        >
          <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6">
            Transform Your Learning Journey with{' '}
            <span className="text-indigo-600">Smart Tutor</span>
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Experience personalized learning with cutting-edge AR/VR technology, live mentoring,
            and research-backed methodologies. Learn smarter, not harder.
          </p>
          
          <div className="flex flex-col sm:flex-row justify-center gap-4 mb-12">
            <motion.button
              whileHover={{ scale: 1.05 }}
              className="bg-indigo-600 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-indigo-700 transition-colors"
            >
              Start Free Trial
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.05 }}
              className="border-2 border-indigo-600 text-indigo-600 px-8 py-4 rounded-lg text-lg font-semibold hover:bg-indigo-50 transition-colors"
            >
              Explore Courses
            </motion.button>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-4xl mx-auto">
            <Stat icon={<Users />} number="50K+" label="Active Students" />
            <Stat icon={<BookOpen />} number="1000+" label="Courses" />
            <Stat icon={<Brain />} number="95%" label="Success Rate" />
            <Stat icon={<Rocket />} number="24/7" label="Expert Support" />
          </div>
        </motion.div>
      </div>
    </div>
  );
};

const Stat = ({ icon, number, label }: { icon: React.ReactNode; number: string; label: string }) => (
  <motion.div
    whileHover={{ y: -5 }}
    className="flex flex-col items-center p-4 rounded-lg bg-white shadow-lg"
  >
    <div className="text-indigo-600 mb-2">{icon}</div>
    <div className="text-2xl font-bold text-gray-900">{number}</div>
    <div className="text-sm text-gray-600">{label}</div>
  </motion.div>
);

export default Hero;