import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { FileText, Download, Search, Filter } from 'lucide-react';

const Research = () => {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1
  });

  const papers = [
    {
      title: "Impact of AR/VR in Modern Education",
      authors: "Dr. Sarah Johnson, Dr. Michael Chen",
      journal: "Journal of Educational Technology",
      date: "2024",
      citations: 156
    },
    {
      title: "Machine Learning Applications in Personalized Learning",
      authors: "Prof. David Miller, Dr. Emily Wong",
      journal: "AI in Education Quarterly",
      date: "2024",
      citations: 89
    },
    {
      title: "Virtual Labs: The Future of Science Education",
      authors: "Dr. Robert Brown, Dr. Lisa Anderson",
      journal: "Science Education Review",
      date: "2023",
      citations: 234
    }
  ];

  return (
    <section id="research" className="py-20 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Research Papers
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Access cutting-edge research papers and stay updated with the latest
            developments in education technology
          </p>
        </motion.div>

        <div className="mb-12">
          <div className="flex flex-col md:flex-row gap-4 mb-8">
            <div className="flex-1 relative">
              <Search className="absolute left-4 top-3 text-gray-400" />
              <input
                type="text"
                placeholder="Search papers..."
                className="w-full pl-12 pr-4 py-3 rounded-lg border border-gray-200 focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
              />
            </div>
            <button className="flex items-center justify-center space-x-2 px-6 py-3 bg-white border border-gray-200 rounded-lg hover:bg-gray-50">
              <Filter className="h-5 w-5" />
              <span>Filters</span>
            </button>
          </div>

          <div className="space-y-6">
            {papers.map((paper, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-white p-6 rounded-xl shadow-lg hover:shadow-xl transition-shadow"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">
                      {paper.title}
                    </h3>
                    <p className="text-gray-600 mb-2">{paper.authors}</p>
                    <div className="flex items-center space-x-4 text-sm text-gray-500">
                      <span>{paper.journal}</span>
                      <span>•</span>
                      <span>{paper.date}</span>
                      <span>•</span>
                      <span>{paper.citations} citations</span>
                    </div>
                  </div>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    className="flex items-center space-x-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
                  >
                    <Download className="h-4 w-4" />
                    <span>Download</span>
                  </motion.button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="text-center"
        >
          <button className="bg-gray-900 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-gray-800 transition-colors">
            Browse All Papers
          </button>
        </motion.div>
      </div>
    </section>
  );
};

export default Research;